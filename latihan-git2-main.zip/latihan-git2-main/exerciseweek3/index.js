const Antrian = require("./exercise3");

const antri = new Antrian()

antri.pesanan("chicken teriyaki")
antri.pesanan("bistik ayam")
antri.pesanan("beef burger")
antri.pesanan("semur jengkol")
antri.pesanan("telor balado")
antri.pesanan("nasi uduk")
antri.pesanan("ketoprak")
antri.pesanan("nasi liwet")
console.log(antri)

// antri.process()