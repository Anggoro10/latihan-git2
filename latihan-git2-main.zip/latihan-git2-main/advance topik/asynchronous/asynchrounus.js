console.log("TASK 1")
setTimeout(() => {
console.log("TASK 2")
}, 4000)
console.log("TASK 3")