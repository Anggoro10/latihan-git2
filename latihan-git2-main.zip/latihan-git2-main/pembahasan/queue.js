    const Queue = require("./exer")

    let obj1 = new addQueue()

    obj1.addQueue("Batagor")
    obj1.addQueue("Sate")
    obj1.addQueue("martabak")

    // console.log(obj1.print())
    
    obj1.run()