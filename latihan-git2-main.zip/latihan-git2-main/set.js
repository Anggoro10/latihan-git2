 let fruits = [ 'apple', 'banana', 'grape', 'mango', 'banana', 'apple', 'orange']
 
 let newFruits = new Set(fruits)

 console.log(newFruits)
 newFruits.add("pepaya")
 newFruits.add("apple")

